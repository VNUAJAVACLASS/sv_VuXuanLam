package dao;

import java.sql.*;
import db.ConnectDB;

public class OrdersDAO {
    private Connection getConnection() throws SQLException { return ConnectDB.getConnection(); }

    public long insertPendingOrder(String appTransId, Long userId, long total) {
        String sql = "INSERT INTO orders(app_trans_id,user_id,total_amount,status) VALUES (?,?,?,'PENDING')";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, appTransId);
            if (userId == null) ps.setNull(2, Types.BIGINT); else ps.setLong(2, userId);
            ps.setLong(3, total);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getLong(1); }
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    public void insertOrderItem(long orderId, int bookId, String title, long price, int qty) {
        String sql = "INSERT INTO order_items(order_id,book_id,title,price,quantity) VALUES (?,?,?,?,?)";
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, orderId); ps.setInt(2, bookId); ps.setString(3, title);
            ps.setLong(4, price); ps.setInt(5, qty);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void markPaid(String appTransId, long zpTransId, int retCode, Integer subRet, String message, String rawCb) {
        try (Connection c = getConnection()) {
            try (PreparedStatement ps = c.prepareStatement("UPDATE orders SET status='PAID' WHERE app_trans_id=?")) {
                ps.setString(1, appTransId); ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO payments(order_id,zp_trans_id,return_code,sub_return_code,message,raw_callback) " +
                    "SELECT id,?,?,?,?,? FROM orders WHERE app_trans_id=?")) {
                ps.setLong(1, zpTransId);
                ps.setInt(2, retCode);
                if (subRet == null) ps.setNull(3, Types.INTEGER); else ps.setInt(3, subRet);
                ps.setString(4, message);
                ps.setString(5, rawCb);
                ps.setString(6, appTransId);
                ps.executeUpdate();
            }
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
